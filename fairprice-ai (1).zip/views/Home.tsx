import React from 'react';

interface HomeProps {
  onStart: () => void;
}

export const Home: React.FC<HomeProps> = ({ onStart }) => {
  return (
    <div className="relative overflow-hidden">
      <section className="relative pt-24 pb-32 lg:pt-40 lg:pb-56">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center max-w-5xl mx-auto">
            <div className="inline-flex items-center gap-3 px-6 py-3 rounded-full bg-blue-50 border border-blue-100 text-blue-600 text-[10px] font-black uppercase tracking-[0.3em] mb-12 shadow-sm animate-bounce">
              <span className="flex h-2 w-2 rounded-full bg-blue-500"></span>
              NEW: PRO AI MODELS FOR HVAC & PLUMBING
            </div>

            <h1 className="text-7xl md:text-9xl font-black text-navy-900 tracking-tighter mb-10 leading-[0.85] gradient-text">
              Fair Market <br className="hidden md:block"/> Service Checks
            </h1>
            <p className="text-xl md:text-2xl text-slate-500 mb-16 leading-relaxed font-medium max-w-3xl mx-auto">
              We use <strong>real-time data grounding</strong> to audit your service quotes. Get fair pricing and custom scripts to save an average of <strong>22%</strong> on your next repair.
            </p>
            
            <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
              <button 
                onClick={onStart}
                className="group relative bg-navy-900 text-white px-16 py-8 rounded-[2.5rem] text-2xl font-black transition-all transform hover:scale-105 shadow-[0_40px_80px_-20px_rgba(0,0,0,0.3)] overflow-hidden"
              >
                Analyze My Quote
              </button>
              <button className="text-navy-900 font-black text-sm uppercase tracking-widest hover:text-blue-600 transition-colors flex items-center gap-3">
                Watch Demo <span className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center">▶</span>
              </button>
            </div>
          </div>
        </div>

        {/* Backdrop Glow */}
        <div className="absolute top-0 left-1/2 -translate-x-1/2 -z-10 w-full max-w-6xl opacity-20">
          <div className="w-full h-[800px] bg-blue-400 rounded-full blur-[200px]"></div>
        </div>
      </section>

      {/* Feature Grid */}
      <section className="bg-white py-40">
        <div className="max-w-7xl mx-auto px-4">
          <div className="grid md:grid-cols-3 gap-20">
            {[
              { icon: '📍', title: 'Hyper-Local', desc: 'Labor rates vary by zip code. We account for regional differences automatically.' },
              { icon: '📜', title: 'Script Engine', desc: 'Get professional, firm scripts to use with your contractor to lower the price.' },
              { icon: '🛡️', title: 'Fraud Check', desc: 'We identify "markup traps" and redundant line items in complex quotes.' }
            ].map((f, i) => (
              <div key={i} className="group">
                <div className="w-20 h-20 bg-slate-50 rounded-3xl flex items-center justify-center text-4xl mb-8 group-hover:bg-blue-600 group-hover:text-white transition-all shadow-inner">
                  {f.icon}
                </div>
                <h3 className="text-2xl font-black text-navy-900 mb-4">{f.title}</h3>
                <p className="text-slate-500 font-medium leading-relaxed">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
};